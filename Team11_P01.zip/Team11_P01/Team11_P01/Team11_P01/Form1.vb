﻿' ***************************************************************** 
' Team Number: 11
' Team Member 1 Details: MAHLAKWANA MJ (222137338)
' Team Member 2 Details: MAHLALELA LO (222221642)
' Team Member 3 Details: MATLHOKO T (217026727)
' Team Member 4 Details:  
' Practical: Team Project 1
' Class name: FORM
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class Frmdiseasemonitor

End Class
